import enum


class eDirection(enum.IntEnum):
    i: int = 0
    j: int = 1
    k: int = 2
